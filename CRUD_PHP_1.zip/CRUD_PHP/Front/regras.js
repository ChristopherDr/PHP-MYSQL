
// // var teste;

// async function validaDados(teste){

//     var nomeUsuario = formulario.nome;
//     var cpfUsuario = formulario.cpf;

//     if (nomeUsuario ==" "){
//         alert("Digite um nome válido!");
//     }



//     // var arm = await fetch("../back/select.php");
//     // var teste = await arm.json();

//     // for($dados of teste){
//     //     if ($user in teste){
//     //         console.log("OK");
//     //     }
//     //     console.log($dados);
//     // }
// }

// validaDados();